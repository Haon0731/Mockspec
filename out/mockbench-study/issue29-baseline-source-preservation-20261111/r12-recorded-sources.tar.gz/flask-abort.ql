import python
import semmle.python.types.FunctionObject

predicate helperAbort(FunctionObject callee) {
  callee.getName() = "abort" and
  callee.getFunction().getLocation().getFile().getRelativePath() = "src/src/flask/helpers.py" and
  callee.getFunction().getLocation().getStartLine() = 265
}

predicate namedCall(Call call, string name) {
  call.getFunc().(Name).getId() = name
  or
  call.getFunc().(Attribute).getName() = name
}

from string relation, AstNode source, AstNode target, string detail
where
  exists(FunctionObject callee, ControlFlowNode callNode, Call call |
    helperAbort(callee) and callee.getACall() = callNode and callNode.getNode() = call and
    call.getLocation().getFile().getRelativePath() = "tests/test_308abort.py" and
    namedCall(call, "abort") and
    relation = "test_call_resolves_to_helper_abort" and source = call and
    target = callee.getFunction() and detail = callee.descriptiveString()
  )
  or
  exists(Call aborter, Call fallback, ControlFlowNode aborterNode, ControlFlowNode fallbackNode |
    namedCall(aborter, "aborter") and namedCall(fallback, "_wz_abort") and
    aborter.getScope().(Function).getName() = "abort" and
    fallback.getScope().(Function).getName() = "abort" and
    aborterNode.getNode() = aborter and fallbackNode.getNode() = fallback and
    aborterNode.strictlyReaches(fallbackNode) and
    relation = "aborter_normal_path_reaches_fallback" and source = aborter and target = fallback and
    detail = "normal CFG reachability"
  )
select relation, source, target, detail,
  source.getLocation().getFile().getRelativePath(), source.getLocation().getStartLine(),
  target.getLocation().getFile().getRelativePath(), target.getLocation().getStartLine()
